     <?php
include('auth.php');
include("connection.php");
$username=$_SESSION['email'];
$id="";$firstname="";$lastname="";$telephone="";$email_address="";$password="";
$supervisor_id="";
$stnts=("SELECT * FROM students WHERE telephone='$username' OR email= '$username'");
$qrys=mysqli_query($conn,$stnts);
//echo $username;
$row=mysqli_fetch_array($qrys);
$id=$row['id'];
$firstname=$row['first_name'];
$lastname=$row['last_name'];
$telephone=$row['telephone'];
$email_address=$row['email'];
$password=$row['password'];
$supervisor_id=$row['supervisor_id'];
$m="";


if(isset($_POST['saves']))
{
    $pids="";
    $tretrieve="SELECT * FROM  `projectstbl` WHERE sid =$id ";
    $tsql=mysqli_query($conn,$tretrieve);
       if($tsql){
    while($row=mysqli_fetch_array($tsql))
    {
     $pids=$row['id'];

    }
   }

   //echo "Data not saved and uploading";
$dates=date('Y-m-d');
$file_type=$_POST['file_type'];
$projectfiles_array = $_FILES['file_array']['name'];
$tmp_name_array = $_FILES['file_array']['tmp_name'];
$type_array = $_FILES['file_array']['type'];
$size_array = $_FILES['file_array']['size'];
$error_array = $_FILES['file_array']['error'];
for($i = 0 ;$i < count($tmp_name_array); $i++){
    if(move_uploaded_file($tmp_name_array[$i],"projectfiles/".$projectfiles_array[$i])){
echo $projectfiles_array[$i]."is uploaded successfully ,,,,,,,,,,,,,,";

}
                                            else{
echo "Data not saved and uploading".$project_files[$i]."failed<br>";
                                            }
                                           }
$binserts="insert  into `project_contents`
(pid,file_type,file_name,addition_date)values
($pids,'$file_type','$projectfiles_array[0]','$dates')";
$bresult = mysqli_query($conn, $binserts);
                 if($bresult)
    {
      echo "<i class='fa fa-info' style='color:red;'>Project uploaded successfully123</i>";
        echo"<script>function redirect(){
window.location='students.php';
}setInterval(redirect,10000);</script>";
   }
    else
         echo "hihihhhhhhhhhhhhhhhhhhhhhhh".mysqli_error();

             }
             ?>


<!DOCTYPE html>
<html class="no-js">
    <head>
        <meta charset="utf-8">
        <title>Final year p</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Fonts -->
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,700' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Dosis:400,700' rel='stylesheet' type='text/css'>

        <!-- Bootsrap -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">


        <!-- Font awesome -->
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">

        <!-- PrettyPhoto -->
        <link rel="stylesheet" href="assets/css/prettyPhoto.css">

        <!-- Template main Css -->
        <link rel="stylesheet" href="assets/css/style.css">

        <!-- Modernizr -->
        <script src="assets/js/modernizr-2.6.2.min.js"></script>


    </head>
    <body>
    <!-- NAVBAR
    ================================================== -->

    <header class="main-header">

       <!-- NAVBAR
    ================================================== -->
                  <div class="navbar-main">

              <div class="container">

                <div class="navbar-header">
                  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">

                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>

                  </button>

<!--                  <a class="navbar-brand" href="index.php"><img src="assets/images/sadaka-logo.png" alt=""></a>-->

                </div>

                <div id="navbar" class="navbar-collapse collapse pull-right">

                  <ul class="nav navbar-nav">






                    <li><a href="logout.php">Signout</a></li>


                  </ul>

                </div> <!-- /#navbar -->

              </div> <!-- /.container -->

            </div> <!-- /.navbar-main -->


        </nav>

    </header> <!-- /. main-header -->



	<div class="main-container">

		<div class="our-causes fadeIn animated">

	        <div class="container">

	           <br>

	            <div class="row">




		                <div class="col-md-3 col-sm-6">

		                    <div class="cause">



		                        <h4 class="cause-title">

                                    <a href="#">
                                     <u><h1>Personal  Infos</h1></u><br>

                                    </a></h4>
		                        <div class="cause-details">
                       <div class="modal-body">

                <form class="form-donation" action="#" method="post">

                        <div class="row">

                          <div class="form-group col-md-2">
                               <label> Email:</label>
                            </div>
                            <div class="form-group col-md-12 ">
  <input type="text" class="form-control" id="amount" name="username" value="<?php echo $email_address?>"required>
                            </div>

                        </div>
                    <div class="row">

                          <div class="form-group col-md-2">
                               <label> Firstname:</label>
                            </div>
                            <div class="form-group col-md-12 ">
  <input type="text" class="form-control" id="amount" name="username" value="<?php echo $firstname?>"required>
                            </div>

                        </div>


                        <div class="row">
                             <div class="form-group col-md-2">
                               <label> Lastname:</label>
                            </div>
                            <div class="form-group col-md-12">
                                <input type="text" class="form-control" name="lname" value="<?php echo $lastname?>">
                            </div>


                        </div>
                    <div class="row">
                         <div class="form-group col-md-2">
                               <label> Tel:</label>
                            </div>
                           <div class="form-group col-md-12">
                                <input type="text" class="form-control" name="password" value="<?php echo $telephone?>">
                            </div>


                        </div>

                    <div class="row">

                            <div class="form-group col-md-4">

                            </div>
                            <div class="form-group col-md-4">
                               <CENTER><button type="submit" class="btn btn-primary pull-right" name="lgn" >UPDATE</button></CENTER>
                            </div>
                            <div class="form-group col-md-4">

                            </div>

                        </div>





                </form>

          </div>
		                        </div>


		                    </div> <!-- /.cause -->

		                </div>

                    <div class="col-md-9">

					<h2 class="title-style-2"><center>Student Dashboard<span class="title-under"></span></h2>


						<div role="tabpanel">

							  <!-- Nav tabs -->
							  <ul class="nav nav-tabs" role="tablist">
							    <li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">MY PROJECT</a></li>
							    <li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">RECORD PROJECT</a></li>
							    <li role="presentation"><a href="#messages" aria-controls="messages" role="tab" data-toggle="tab">PROJECT CONTENTS</a></li>
							    <li role="presentation"><a href="#settings" aria-controls="settings" role="tab" data-toggle="tab">ADD PROJECT CONTENTS</a></li>
							  </ul>

							  <!-- Tab panes -->
							  <div class="tab-content">
							    <div role="tabpanel" class="tab-pane active" id="home">
                               <?php $mids="";$module_name="";
$tretrieve="SELECT *
FROM  `projectstbl` WHERE
sid =$id
";
$tsql=mysqli_query($conn,$tretrieve);
$num=mysqli_num_rows($tsql);
if($num>0){
while($row=mysqli_fetch_array($tsql))
{
 $mids=$row['id'];
 //$teacher_id=$row['teacher_id'];
 $module_name=$row['name'];
 $module_details=$row['detail'];
$category=$row['category'];

    $wordcontents=wordwrap($module_details,30,"<br/>",true);
echo' <div class="col-md-8 col-sm-8"> <div class="cause" style="height:300px;"><h4 class="cause-title"><a href="#">Project Name:'.$module_name.'</a></h4>
                        <div class="cause-details">
                     '.$wordcontents.'<br><h5><b> Category:'.$category.'
                        </div> </h5></b>';
    echo "<div class='btn-holder text-center'>";
//'<a href='trainerspage.php?edit={$row['id']}' style='align:bottom;'>More </a>'

echo "</div></div></div>";

}



}
else
{
    echo' <div class="col-md-8 col-sm-8"> <div class="cause" style="height:300px;">
   <h1><b> <div class="cause-details"><br><br><br>
<center>YOU HAVE NOT YET UPLOADED YOUR PROJECT  </center>
    </div> </h1></b>';
echo "</div></div>";

}
?>

                                    <?php if(isset($_GET['edit'])){
                 $delid=isset($_GET['edit']);
echo"<center><h1><a href='trainerspage.php?remove={$_GET['edit']}'><i class='fa fa-trash' style='color:red;'></i></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='#' class='btn btn-default' data-toggle='modal' data-target='#donateModal'><i class='fa fa-folder-open-o'></i></a>   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href='trainerspage.php'><i class='fa fa-refresh' style='color:black;'></i></a></h1></i></center>";

             }
                                    if(isset($_GET['remove']))
                                    {
                                        $del=$_GET['remove'];
echo"<center><h2>Do you really want to Detele the module with {$del} ?<a href='trainerspage.php?yes={$del}'><i class='fa fa-check' style='color:red;'></i></a>&nbsp;&nbsp;&nbsp;<a href='trainerspage.php'><i class='fa fa-times' style='color:red;'></i></a></h2></i></center>";
                                                                      }
                                    if(isset($_GET['yes']))
                                    {
                                    $target=$_GET['yes'];
   echo $target;
   $v="delete from modulecontents where m_id=$target";
$mcqry=mysqli_query($conn,$v);
 $dq="delete from modules where m_id=$target";
   $mqry=mysqli_query($conn,$dq);
                                        if($mqry)
                                        {
 echo"<center><h2><i class='fa fa-check' style='color:red;'></i></h2></center>";
  echo"<script>function redirect(){
window.location='students.php';
}setInterval(redirect,10000);</script>"; }
                                        else
                                        {
echo"<center><h2><i class='fa fa-warning' style='color:red;'> not deleted</i></h2></center";
 echo"<script>function redirect(){
window.location='students.php';
}setInterval(redirect,1000);</script>";

                                        }
                                        }
                                    ?>


<!--                    <div class="cause">-->
<?php
// $mids="";$module_name="";
// $tretrieve="SELECT *
// FROM  `projectstbl` WHERE
// sid =$id
// ";
// $tsql=mysqli_query($conn,$tretrieve);

// if($tsql){
// while($row=mysqli_fetch_array($tsql))
// {
//  $pids=$row['sid'];




// }



// }
?>


                     <!-- /.cause -->


							</div>

							    <div role="tabpanel" class="tab-pane" id="profile">
							    		    	     <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
           <!-- project details -->

              <!-- project details -->
    <center><h4 class="modal-title" id="donateModalLabel">
        <?php
             if(isset($_POST['savemodule']))
             {
   $topics=$_POST['topics'];
    $details=$_POST['details'];
    $category=$_POST['category'];
  $minserts="insert  into `projectstbl`(sid,name,detail,category)values
($id,'$topics','$details','$category')";
$mresult = mysqli_query($conn,$minserts);
     if($mresult)
     {
     $m="Data inserted correctly";
 echo"<script>function redirect(){
window.location='students.php';
}setInterval(redirect,1000);</script>";

     }
                 else
                  $m=mysqli_error($conn);


             }
              echo $m;?>Project Registration form
        </h4></center>

          </div>
          <div class="modal-body">

<form class="form-donation" method="POST" action="#">
             <div class="row">
 <div class="form-group col-md-12 ">
<input type="text" class="form-control" id="amount" placeholder="PROJECT NAME *" required name="topics">  </div>
                        </div>
     <div class="row">
                            <div class="form-group col-md-12">
                                <textarea type="text" class="form-control" name="details" placeholder="project brief Description Summary 200; words is the maximum" rows="7" required maxlength="200"></textarea>
                            </div>


                        </div>   <div class="row">
                            <div class="form-group col-md-12">
          <select class="form-control" name="category">
                                <option>ICT</option>
                                    <option>ELECTRONICS</option>
                                    <option>CIVIL ENGENEERING</option>
                                    <option>CARNARY-6-MONTH</option>
                                              </select>
                            </div>


                        </div>
                   <div class="row">

                            <div class="form-group col-md-4">

                            </div>
                            <div class="form-group col-md-4">
<CENTER><button type="submit" class="btn btn-primary pull-right" name="savemodule" >Submit</button></CENTER>
                            </div>
                            <div class="form-group col-md-4">

                            </div>

                        </div>
               </form>

          </div>
        </div>
      </div>
						</div>
							    <div role="tabpanel" class="tab-pane" id="messages">
                                        <table class="table table-style-1">

							    	<?php
               $hid="";
$ds="select * from projectstbl where sid=$id";
$ssql=mysqli_query($conn,$ds);
$module_name="";
$srow=mysqli_fetch_array($ssql);
$hid=$srow['id'];
    $x="select * from project_contents where pid=$hid";
$msql=mysqli_query($conn,$x);
//$nmz=mysqli_num_rows($msql);
echo'<thead>
              <tr>

                <th>File Name</th>
                <th>FIle Type</th>
                            <th>Date</th>
                            <th>Option</th>
              </tr>
            </thead>
            <tbody>

<tr>';
if ($msql)
{

    while($mrecs=mysqli_fetch_array($msql))
    {

    $file_type=$mrecs['file_type'];
    $file_name=$mrecs['file_name'];
    $addition_date=$mrecs['addition_date'];

    echo'


					          <td>'.$file_name.'</td>
                    <td>'.$file_type.'</td>
					          <td>'.$addition_date.'</td>
                             <td></td></tr>';
       // echo"<td><a href=test.php?decide={$id}>Activate</a></td>
			//		        </tr>";
                        }}
                        else
                        echo "no content yet";


      ?>

                      </tbody>
					    </table>
                                  </div>
							    <div role="tabpanel" class="tab-pane" id="settings">
							    	  <div class="modal-body">
<form class="form-donation" method="POST" enctype="multipart/form-data" action="#">
<!--    <form role="form" method="post" enctype="multipart/form-data" action="#">-->

                    <div class="row">


                                <?php
                                        ?>


                        </div>
    <div class="row">
 <div class="form-group col-md-12 ">
<select type="text" class="form-control" id="amount"  required name="file_type">
<option>project_report</option>
<option>video_tutorial</option>
<option>project_file</option>
</select>

</div>

                        </div>
                        <div class="row">
                            <div class="form-group col-md-6">
                                <label><h3> Choose file</h3></label>
                            </div>
                        <div class="form-group col-md-6">

<input type="file" name="file_array[]"class="form-control" required>
                            </div>
                       </div>
                   <div class="row">

                            <div class="form-group col-md-4">

                            </div>
                            <div class="form-group col-md-4">
<CENTER><button type="submit" class="btn btn-primary pull-right" name="saves" >Submit</button></CENTER>
                            </div>
                            <div class="form-group col-md-4">

                            </div>

                        </div>
               </form>

          </div>

                                  </div>
							  </div>

						</div>

						<p></p>


				</div>


	            </div>

	         </div>

	    </div> <!-- /.our-causes -->




	</div> <!-- /.main-container  -->

 <footer class="main-footer">

        <div class="footer-top">

        </div>


        <div class="footer-main">
            <div class="container">

                <div class="row">
                    <div class="col-md-4">



                        </div>

                    </div>

                                      <div class="clearfix"></div>



                </div>


            </div>


        </div>

        <div class="footer-bottom">

            <div class="container text-right">
             <br>
            </div>
        </div>

    </footer>


        <!-- Donate Modal -->
          <div class="modal fade" id="donateModal" tabindex="-1" role="dialog" aria-labelledby="donateModalLabel" aria-hidden="true">

      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="donateModalLabel"><?php echo $module_name?> Contents Details </h4>
          </div>
          <div class="modal-body">

              <?php

if(isset($_GET['edit'])){
$var=$_GET['edit'];
$y="select * from modulecontents where m_id=$var";
     $sql_qry=mysqli_query($conn,$y);
    $rows=mysqli_num_rows($sql_qry);
    if($rows>0){
          echo'<table class="table table-style-1">
	<thead><tr><th>Chapter</th><th>Details</th><th>Publcation Date</th><th>File</th>
   <th>Option</th></tr></thead><tbody>';
    while($recs=mysqli_fetch_array($sql_qry))
    {
    $c_id=$recs['id'];
    $c_m_id=$recs['m_id'];
    $c_chapter=$recs['Course_level'];
    $c_course_details=$recs['course_details'];
    $c_course_tutorial=$recs['course_tutorial'];
    $c_publication_date=$recs['publication_date'];
     $wordcontents=wordwrap($c_course_details,20,"<br/>",true);
        $wordchapter=wordwrap($c_chapter,10,"<br/>",true);

        echo'
					        <tr>
					          <th scope="row">'.$c_chapter.'</th>
					          <td>'.$wordcontents.'</td>
					          <td>'.$c_publication_date.'</td>
<td><a href=\'projectfiles/'.$c_course_tutorial.'\' >'.'Read file<a/></td>
                              <td><i class="fa fa-edit" style="color:black;"></i>||';
        echo"<a href='test.php?delm={$c_id}' style='align:bottom;'><i class='fa fa-trash' style='color:black;'></i> </a></td>
					        </tr>";
    }
        echo"</tbody>
					    </table>";
    }

    else
        echo "<h1><i class='fa fa-warning' style='color:black;'> The module does not have contents yet</i></h1>";
   }

              ?>


              <br> <br>
              <div class="row">
            <div class="form-group col-md-12">
                            </div>
              </div>
          </div>
        </div>
      </div>

    </div>
        <!-- jQuery -->
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
        <script>window.jQuery || document.write('<script src="assets/js/jquery-1.11.1.min.js"><\/script>')</script>

        <!-- Bootsrap javascript file -->
        <script src="assets/js/bootstrap.min.js"></script>

        <!-- PrettyPhoto javascript file -->
        <script src="assets/js/jquery.prettyPhoto.js"></script>



        <!-- Google map  -->
        <script src="http://maps.google.com/maps/api/js?sensor=false&amp;libraries=places" type="text/javascript"></script>


        <!-- Template main javascript -->
        <script src="assets/js/main.js"></script>

        <!-- Google Analytics: change UA-XXXXX-X to be your site's ID. -->
        <script>
            (function(b,o,i,l,e,r){b.GoogleAnalyticsObject=l;b[l]||(b[l]=
            function(){(b[l].q=b[l].q||[]).push(arguments)});b[l].l=+new Date;
            e=o.createElement(i);r=o.getElementsByTagName(i)[0];
            e.src='//www.google-analytics.com/analytics.js';
            r.parentNode.insertBefore(e,r)}(window,document,'script','ga'));
            ga('create','UA-XXXXX-X');ga('send','pageview');
        </script>
    </body>
</html>
