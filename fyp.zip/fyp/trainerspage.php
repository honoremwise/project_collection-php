     <?php
include("connection.php");
include'auth.php';
$username=$_SESSION['email'];
$m="";$id="";$firstname="";$lastname="";$telephone="";$email_address="";$password="";
$z="select * from teachers where telephone ='$username' or email_address = '$username'";
$qry=mysqli_query($conn,$z);
if($qry)
{
$row=mysqli_fetch_array($qry);
$id=$row['id'];
$firstname=$row['fname'];
$lastname=$row['lname'];
$telephone=$row['telephone'];
$email_address=$row['email_address'];
$password=$row['password'];
}
if(!$qry){
  $m=mysqli_error();
}
             ?>
<!DOCTYPE html>
<html class="no-js">
    <head>
        <meta charset="utf-8">
        <title>FInal year project</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Fonts -->
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,700' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Dosis:400,700' rel='stylesheet' type='text/css'>

        <!-- Bootsrap -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">


        <!-- Font awesome -->
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">

        <!-- PrettyPhoto -->
        <link rel="stylesheet" href="assets/css/prettyPhoto.css">

        <!-- Template main Css -->
        <link rel="stylesheet" href="assets/css/style.css">

        <!-- Modernizr -->
        <script src="assets/js/modernizr-2.6.2.min.js"></script>


    </head>
    <body>
    <!-- NAVBAR
    ================================================== -->

    <header class="main-header">

       <!-- NAVBAR
    ================================================== -->
       <nav class="navbar navbar-static-top">


            <div class="navbar-main">

              <div class="container">

                <div class="navbar-header">
                  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">

                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>

                  </button>

<!--                  <a class="navbar-brand" href="index.php"><img src="assets/images/sadaka-logo.png" alt=""></a>-->

                </div>

                <div id="navbar" class="navbar-collapse collapse pull-right">

                  <ul class="nav navbar-nav">






                    <li><a href="logout.php">Signout</a></li>


                  </ul>

                </div> <!-- /#navbar -->

              </div> <!-- /.container -->

            </div> <!-- /.navbar-main -->


        </nav>

    </header> <!-- /. main-header -->



	<div class="main-container">

		<div class="our-causes fadeIn animated">

	        <div class="container">

	           <br>

	            <div class="row">




		                <div class="col-md-3 col-sm-6">

		                    <div class="cause">



		                        <h4 class="cause-title">

                                    <a href="#">
                                     <u><h1>Personal  Infos</h1></u><br>

                                    </a></h4>
		                        <div class="cause-details">
                       <div class="modal-body">

                <form class="form-donation" action="#" method="post">

                        <div class="row">

                          <div class="form-group col-md-2">
                               <label> Email:</label>
                            </div>
                            <div class="form-group col-md-12 ">
  <input type="text" class="form-control" id="amount" name="username" value="<?php echo $email_address?>"required>
                            </div>

                        </div>
                    <div class="row">

                          <div class="form-group col-md-2">
                               <label> Firstname:</label>
                            </div>
                            <div class="form-group col-md-12 ">
  <input type="text" class="form-control" id="amount" name="username" value="<?php echo $firstname?>"required>
                            </div>

                        </div>


                        <div class="row">
                             <div class="form-group col-md-2">
                               <label> Lastname:</label>
                            </div>
                            <div class="form-group col-md-12">
                                <input type="text" class="form-control" name="lname" value="<?php echo $lastname?>">
                            </div>


                        </div>
                    <div class="row">
                         <div class="form-group col-md-2">
                               <label> Tel:</label>
                            </div>
                           <div class="form-group col-md-12">
                                <input type="text" class="form-control" name="password" value="<?php echo $telephone?>">
                            </div>


                        </div>

                    <div class="row">

                            <div class="form-group col-md-4">

                            </div>
                            <div class="form-group col-md-4">
                               <CENTER><button type="submit" class="btn btn-primary pull-right" name="lgn" >UPDATE</button></CENTER>
                            </div>
                            <div class="form-group col-md-4">

                            </div>

                        </div>





                </form>

          </div>
		                        </div>


		                    </div> <!-- /.cause -->

		                </div>

                    <div class="col-md-9 fadeIn">

					<h2 class="title-style-2"><center>SUPERVISOR Dashboard<span class="title-under"></span></h2>
            <?php
            if(isset($_GET['full'])){
                           echo"<center><a href='#' data-toggle='modal' data-target='#donateModal'><i class='fa fa-eye'> More </i></a></center>";


            }
            ?>

						<div role="tabpanel">

							  <!-- Nav tabs -->
							  <ul class="nav nav-tabs" role="tablist">
							    <li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">STUDENTS PROJECTS</a></li>
							    <li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">PENDING PROJECTS</a></li>
							    <li role="presentation"><a href="#messages" aria-controls="messages" role="tab" data-toggle="tab">COMPLETED PROJECTS</a></li>
							   <li role="presentation"><a href="#settings" aria-controls="settings" role="tab" data-toggle="tab"></a></li>
							  </ul>

							  <!-- Tab panes -->
							  <div class="tab-content">
							    <div role="tabpanel" class="tab-pane active" id="home">
                    <div class="row">

                                    <div role="tabpanel" class="tab-pane active" id="home">
                      <?php
        include("connection.php");
        $m_id="";$teacher_id="";$category="";
//$ds="select projectstbl.*,students.* from projectstbl,students where projectstbl.decision !='completed' and students.supervisor_id=$id";
    $ds="select students.*,projectstbl.*,teachers.* from students,projectstbl,teachers where
      students.supervisor_id=$id and teachers.id=$id and projectstbl.sid=$id limit 1";
        $projectstbl=mysqli_query($conn,$ds);
        $num=mysqli_num_rows($projectstbl);
        if($num>0)
        {
        while($recs=mysqli_fetch_array($projectstbl))
        {
        $m_id=$recs['id'];
        $name=$recs['name'];
                 $details=$recs['detail'];
          $category=$recs['category'];
            if($category=="ICT"){
            echo" <div class='col-md-3'>

                            <div class='reasons-col'>

                 <h1><i class='fa fa-file-code-o' style='font-size:700%'></i></h1>
                                <div class='reasons-titles'>

                                    <h3 class='reasons-title'>".$name.$m_id."</h3>
                                    <h5 class='reason-subtitle'>&nbsp;&nbsp;Category:".$category."</h5>

                                </div>

                                <div class='on-hover hidden-xs'>";
            echo"<center><h4><u>Project Short Description</u><h4></center>";
         echo'

                                        <p> '.$details.'
                                                                        </p>

                                     ';
                             echo"
                                </div>
                            </div>

                        </div>";

            }
            else if($category=="ELECTRONICS")
            {
            echo' <div class="col-md-3">

                            <div class="reasons-col">

                 <h1><i class="fa fa-wrench" style="font-size:700%"></i></h1>
                                <div class="reasons-titles">

                                    <h3 class="reasons-title">'.$name.'</h3>
                                    <h5 class="reason-subtitle"> <a href="#" data-toggle="modal" data-target="#donateModal"><i class="fa fa-eye"> More </i></a>Category:'.$category.'</h5>

                                </div>

                                <div class="on-hover hidden-xs">';
            echo"<center><h4><u>projectShort Description</u><h4></center>";
         echo'

                                        <p> '.$details.'
                                                                        </p>

                                      ';
                           echo"
                                </div>
                            </div>

                        </div>";

            }
            else if($category=="CIVIL ENGENEERING")
           {
            echo' <div class="col-md-3">

                            <div class="reasons-col">

                 <h1><i class="fa fa-home" style="font-size:700%"></i></h1>
                                <div class="reasons-titles">

                                    <h3 class="reasons-title">'.$name.'</h3>
                                    <h5 class="reason-subtitle"> <a href="#" data-toggle="modal" data-target="#donateModal"><i class="fa fa-eye"> More </i></a>Category:'.$category.'</h5>
                                </div>

                                <div class="on-hover hidden-xs">';
            echo"<center><h4><u>Project Short Description</u><h4></center>";
         echo'
                                        <p> '.$details.'
                                                                        </p>
        ';
                           echo"
                                </div>
                            </div>

                        </div>";

            }
        else
        {
            echo' <div class="col-md-3">

                            <div class="reasons-col">

                 <h1><i class="fa fa-cutlery" style="font-size:700%"></i></h1>
                                <div class="reasons-titles">

                                    <h3 class="reasons-title">'.$name.'</h3>
                                    <h5 class="reason-subtitle">Category:'.$category.'</h5>

                                </div>

                                <div class="on-hover hidden-xs">';
            echo"<center><h4><u>Mproject Short Description</u><h4></center>";
         echo'
                                        <p> '.$details.'
                                                                        </p>

                                        ';
                          echo"
                                </div>
                            </div>

                        </div>";
            echo"<br>";

            }

        }

        }
        else if($num<0){
echo "<center><h1>None of your students uploaded his or her project yet<br></h1></center>";

        }
        else {
          echo mysqli_error($conn);
        }

                                            ?>

                      </div>
                </div>


                     <!-- /.cause -->


							</div>

							    <div role="tabpanel" class="tab-pane" id="profile">

        <div class="modal-content">
          <div class="modal-header">
           <!-- project details -->

              <!-- project details -->
    <center><h4 class="modal-title" id="donateModalLabel">
      Uncompleted projects
        </h4></center>

          </div>
          <div class="modal-body">


            <?php
//$ins=mysqli_query($connect,"SELECT borrow.*,books.*,Member.* FROM borrow,books,member where date>='$from' and date<='$to'
// and borrow.book_id=books.book_id and borrow.member_code=member.member_code");
//  $ds="select projectstbl.*,students.* from projectstbl,students where projectstbl.decision !='completed' and students.supervisor_id=$id";
  $ds="select projectstbl.*,students.*,teachers.* from projectstbl,students,teachers where students.supervisor_id=$id and teachers.id=$id and projectstbl.sid=$id and projectstbl.decision !='completed' limit 1";
            $ssql=mysqli_query($conn,$ds);
            $var=mysqli_num_rows($ssql);
            if($var>0){
              echo'<table class="table table-style-1">
              <thead>
              <tr>
                <th>Project</th>
              <th>Description</th>
              <th>Student</th>
              <th>Student Tel</th>
              <th>Options</th>
              </tr>
              </thead>
              <tbody>';
                while($srow=mysqli_fetch_array($ssql))
            {
            $pids=$srow['id'];
            $sid=$srow['sid'];
            $pname=$srow['name'];
            $detail=$srow['detail'];
            $decision=$srow['decision'];
            $first_name=$srow['first_name'];
            $last_name=$srow['last_name'];
            $telephones=$srow['telephone'];


            echo'<tr>

            <td>'.$pname.'</td>
            <td>'.$detail.'</td>
            <td>'.$last_name.'</td>
            <td>'.$telephones.'</td>';
            echo"<td><a href=trainerspage.php?full={$pids}>Approve completion</a>
              </td>
            </tr>";
            }
            echo'</tbody>
            </table>';
}
else{
echo"<center><h1>No Pending Projects Uploaded so far</h1></center>";
}

            ?>



          </div>

      </div>
						</div>
							    <div role="tabpanel" class="tab-pane" id="messages">

							    	<?php
$ds="select students.*,projectstbl.*,teachers.* from students,projectstbl,teachers
where students.supervisor_id=$id and teachers.id=$id and projectstbl.sid=$id and projectstbl.decision ='completed'";
$ssql=mysqli_query($conn,$ds);
$number=mysqli_num_rows($ssql);
if($number){
  echo'    <table class="table table-style-1">
<thead>
<tr>
<th>Project</th>
<th>Project short details</th>
<th>students</th>
<th>Telephone</th>
<th>Options</th>
</tr>
</thead>
<tbody>';
    while($srow=mysqli_fetch_array($ssql))
{
$pid=$srow['id'];
$sid=$srow['sid'];
$pname=$srow['name'];
$detail=$srow['detail'];
$decision=$srow['decision'];

//  $sid=$mrecs['id'];
$first_name=$srow['first_name'];
$last_name=$srow['last_name'];
$telephones=$srow['telephone'];


echo'<tr>

<td>'.$pname.'</td>
<td>'.$detail.'</td>
<td>'.$first_name.'</td>
<td>'.$telephones.'</td>';
echo"<td><a href=test.php?decide={$pid}>Edit status</a></td>
</tr>";
}
echo"</tbody>
</table>";
}
else {
  echo"<center><h1>no student completed his project yet!</h1></center>";
}

      ?>


                                  </div>
							    <div role="tabpanel" class="tab-pane" id="settings">
							    	  <div class="modal-body">
jjjjjjj
          </div>

                                  </div>
							  </div>

						</div>

						<p></p>


				</div>


	            </div>

	         </div>

	    </div> <!-- /.our-causes -->




	</div> <!-- /.main-container  -->

 <footer class="main-footer">

        <div class="footer-top">

        </div>


        <div class="footer-main">
            <div class="container">

                <div class="row">
                    <div class="col-md-4">



                        </div>

                    </div>

                                      <div class="clearfix"></div>



                </div>


            </div>


        </div>

        <div class="footer-bottom">

            <div class="container text-right">

             <br>
            </div>
        </div>

    </footer>
<!-- model -->
<div class="modal fade" id="donateModal" tabindex="-1" role="dialog" aria-labelledby="donateModalLabel" aria-hidden="true">

   <div class="modal-dialog">
     <div class="modal-content">
<?php
$name="";
if(isset($_GET['full']))
{
$fid=$_GET['full'];

$dc="select * from projectstbl where sid =$fid and decision ='pending'";
$qry=mysqli_query($conn,$dc);
//echo $username;
$row=mysqli_fetch_array($qry);
$id=$row['id'];
$name=$row['name'];
$detail=$row['detail'];
$category=$row['category'];

}
?>
       <div class="modal-body">
         <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      <u> <h2><center> <?php echo mb_strtoupper($name) ?>Project Contents</u><?php   echo"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=test.php?full={$pids}><u>Approve</a>"?></center></h2></u>
           <br> <br>
           <div class="row">
             <?php
             $pid="";
             if(isset($_GET['full']))
             {
             $fid=$_GET['full'];

             $dc="select * from projectstbl where sid =$fid and decision ='pending'";
             $qry=mysqli_query($conn,$dc);
             //echo $username;
             $row=mysqli_fetch_array($qry);
             $pid=$row['id'];
             $name=$row['name'];
             $detail=$row['detail'];
             $category=$row['category'];

             }
             $qry="select * from project_contents where pid=$pid";
             $sr=mysqli_query($conn,$qry);
             while ($read=mysqli_fetch_array($sr)) {
             $file_type=$read['file_type'];
             $file_name=$read['file_name'];
             // code...
             if($file_type=="video_tutorial"){
             echo"
              <div class='about-us-col col-md-12'>
                      <h4 class='col-title'> $file_type</h4>
                        <div class='col-details'>

             <video width='500px' height='200px' controls>
             <source src='projectfiles/$file_name' type='video/mp4'
             <video>


                                      </div>
             <a href='projectfiles/$file_name'><i class='fa fa-download'></i></a>

                                </div>



                             ";
             }
             else if($file_type=="project_file"){
             echo"
              <div class='about-us-col col-md-12'>
                      <h5 class='col-title'> $file_type</h5>
                        <div class='col-details'>

             <center>
             <k class='fa fa-file-zip-o' style='width:600px;height:100px;font-size:200px;'></k></center><br>

                                      </div>
             <a href='projectfiles/$file_name' title='download'><i class='fa fa-download'></i></a>

                                </div>



                             ";
             }
             else if($file_type=="project_report"){
             echo"
              <div class='about-us-col col-md-12'>
                      <h4 class='col-title'> $file_type</h4>
                        <div class='col-details'>
             <center>

             <k class='fa fa-file-pdf-o' style='width:100%;height:250%;font-size:200px;'></k>
             </center>
                                      </div>

             <a href='projectfiles/$file_name'><i class='fa fa-download'></i></a>
                                </div>
                                <div class='col-md-1'>


                                </div>


                             ";
             }
             else{
             echo "no contents yet";
             }
             }

             ?>
           </div>
       </div>
     </div>
   </div>

 </div>

        <!-- Donate Modal -->

        <!-- jQuery -->
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
        <script>window.jQuery || document.write('<script src="assets/js/jquery-1.11.1.min.js"><\/script>')</script>

        <!-- Bootsrap javascript file -->
        <script src="assets/js/bootstrap.min.js"></script>

        <!-- PrettyPhoto javascript file -->
        <script src="assets/js/jquery.prettyPhoto.js"></script>



        <!-- Google map  -->
        <script src="http://maps.google.com/maps/api/js?sensor=false&amp;libraries=places" type="text/javascript"></script>


        <!-- Template main javascript -->
        <script src="assets/js/main.js"></script>

        <!-- Google Analytics: change UA-XXXXX-X to be your site's ID. -->
        <script>
            (function(b,o,i,l,e,r){b.GoogleAnalyticsObject=l;b[l]||(b[l]=
            function(){(b[l].q=b[l].q||[]).push(arguments)});b[l].l=+new Date;
            e=o.createElement(i);r=o.getElementsByTagName(i)[0];
            e.src='//www.google-analytics.com/analytics.js';
            r.parentNode.insertBefore(e,r)}(window,document,'script','ga'));
            ga('create','UA-XXXXX-X');ga('send','pageview');
        </script>
    </body>
</html>
