<?php
include("connection.php");
include'auth.php';

if(isset($_GET['full']))
 {
$id=$_GET['full'];


$proj="update projectstbl set decision='completed' where sid=$id";
$up=mysqli_query($conn,$proj);
if($up){
  echo"Project Approved successfully";
  echo"<script>
function redirect(){
  window.location='trainerspage.php';
}setInterval(redirect,1000)
  </script>";
}


}
else if(isset($_GET['decide']))
{
$var=$_GET['decide'];
    echo $var;
    $cv="update projectstbl set decision='pending' where sid=$var";
    $sql=mysqli_query($conn,$cv);
    if($sql)
    {
    echo"status changed successfully";
        echo"<script>function redirect(){
window.location='trainerspage.php';
}setInterval(redirect,1000);</script>";
    }

}
else if(isset($_GET['delm']))
{
    $del=$_GET['delm'];
    echo"<br><br><br><center><form action='#' method='post'><input type='submit' name='ye' value='delete?'>&nbsp;&nbsp;&nbsp;&nbsp;or&nbsp;&nbsp;&nbsp;&nbsp;<input type='submit' name='no' value='reflesh?'></form></center>";

    if(isset($_POST['ye']))
       {
        $xz="delete from modulecontents where id=$del";
$delqry=mysqli_query($conn,$xz);
        if($delqry)
        {
        echo "query ok";
 echo"<script>function redirect(){
window.location='trainerspage.php';
}setInterval(redirect,100);</script>";
        }
       }
    else if(isset($_POST['no']))
            {
            echo"<script>function redirect(){
window.location='trainerspage.php';
}setInterval(redirect,100);</script>";
            }

}
else if(isset($_GET['aproveh']))
{
echo "<br><br><br><center><form action='#' method='post'>
<input type='submit' value='sure approve subcription?' name='apsub'> &nbsp;&nbsp;&nbsp;or &nbsp;&nbsp;&nbsp;
<input type='submit' value='Back' name='rejsub'>
</form></center>";
    if(isset($_POST['apsub']))
    {
        $apvar=$_GET['aproveh'];
        $vx="update learning_history set decision='approved' where id=$apvar";
$del=mysqli_query($conn,$vx);
        if($del)
        {
        echo"approved successfully";
          echo"<script>function redirect(){
window.location='manage.php';
}setInterval(redirect,100);</script>";
        }
    }
    else if(isset($_POST['rejsub']))
    {
    echo"<script>function redirect(){
window.location='manage.php';
}setInterval(redirect,100);</script>";
    }
}
else if(isset($_GET['st_actvate'])){
    $acid=$_GET['st_actvate'];
    $lz="update teachers set status='active' where id=$acid";
$ac=mysqli_query($conn,$lz);
    if($ac)
    {
      echo"activated successfully";
          echo"<script>function redirect(){
window.location='manage.php';
}setInterval(redirect,100);</script>";
    }
}
else if(isset($_GET['st_desactvate'])){
$deacid=$_GET['st_desactvate'];
    $bs="update teachers set status='inactive' where id=$deacid";
$dea=mysqli_query($conn,$bs);
    if($dea)
    {
      echo"Account desactivated successfully";
          echo"<script>function redirect(){
window.location='manage.php';
}setInterval(redirect,100);</script>";
    }
}

else
{
echo mysqli_error($conn);
}
?>
