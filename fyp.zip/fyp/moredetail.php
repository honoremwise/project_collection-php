<?php
include("connection.php");
$id=""; $name="";
if(isset($_GET['more']))
{
$id=$_GET['more'];

$dc="select * from projectstbl where id =$id and decision !='pending'";
$qry=mysqli_query($conn,$dc);
//echo $username;
$row=mysqli_fetch_array($qry);
$id=$row['id'];
$name=$row['name'];
$detail=$row['detail'];
$category=$row['category'];

}
?>
<!DOCTYPE html>
<html class="no-js">
    <head>
        <meta charset="utf-8">
        <title>FYP</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Fonts -->
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,700' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Dosis:400,700' rel='stylesheet' type='text/css'>

        <!-- Bootsrap -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">


        <!-- Font awesome -->
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">

        <!-- PrettyPhoto -->
        <link rel="stylesheet" href="assets/css/prettyPhoto.css">

        <!-- Template main Css -->
        <link rel="stylesheet" href="assets/css/style.css">

        <!-- Modernizr -->
        <script src="assets/js/modernizr-2.6.2.min.js"></script>


    </head>
    <body>
    <!-- NAVBAR
    ================================================== -->

    <header class="main-header">

       <!-- NAVBAR
    ================================================== -->
       <nav class="navbar navbar-static-top">


            <div class="navbar-main">

              <div class="container">

                <div class="navbar-header">
                  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">

                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>

                  </button>



                </div>

                <div id="navbar" class="navbar-collapse collapse pull-right">

                  <ul class="nav navbar-nav">
 <li><a href="index.php">Back</a></li>


                  </ul>

                </div> <!-- /#navbar -->

              </div> <!-- /.container -->

            </div> <!-- /.navbar-main -->


        </nav>

    </header> <!-- /. main-header -->
	<div class="main-container">

		<div class="our-causes fadeIn animated">

	        <div class="container">

	                <div class="row">

                        <!--php codes--->



	   <div class="col-md-3 col-sm-6">

		                    <div class="cause">



		                        <h4 class="cause-title">

                                    <a href="#">
                                     <u><h1><?php echo Ucfirst($name);?></h1></u><br>

                                    </a></h4>
		                        <div class="cause-details">
                       <div class="modal-body">
<?php
/*to minimize*/
$x=wordwrap($detail,30);
echo "<h4>".$x."</h4><br><br>";
echo "<b>Category:".$category."</b>";
                        ?>


          </div>
		                        </div>


		                    </div>
                        </div>

               <div class="col-md-7 col-sm-7">

      <div class="modal-dialog">
	<h2 class="title-style-2"> Project Contents <span class="title-under"></span></h2>

				<div class="col-md-12">
<?php

$qry="select * from project_contents where pid=$id";
$sr=mysqli_query($conn,$qry);
while ($read=mysqli_fetch_array($sr)) {
  $file_type=$read['file_type'];
  $file_name=$read['file_name'];
  // code...
  if($file_type=="video_tutorial"){
  echo"
       <div class='about-us-col col-md-4'>
               <h4 class='col-title'> $file_type</h4>
                 <div class='col-details'>

<video width='150px' height='150px' controls>
<source src='projectfiles/$file_name' type='video/mp4'
<video>


                               </div>
<a href='projectfiles/$file_name'><i class='fa fa-download'></i></a>

                         </div>



                      ";
}
else if($file_type=="project_file"){
  echo"
       <div class='about-us-col col-md-4'>
               <h4 class='col-title'> $file_type</h4>
                 <div class='col-details'>

</center>
<k class='fa fa-file-zip-o' style='width:100px;height:100px;font-size:150px;'></k></center>

                               </div>
<a href='projectfiles/$file_name'><i class='fa fa-download'></i></a>

                         </div>



                      ";
}
else if($file_type=="project_report"){
  echo"
       <div class='about-us-col col-md-4'>
               <h4 class='col-title'> $file_type</h4>
                 <div class='col-details'>
<center>

<k class='fa fa-file-pdf-o' style='width:100%;height:250%;font-size:150px;'></k>
</center>
                               </div>

<a href='projectfiles/$file_name'><i class='fa fa-download'></i></a>
                         </div>
                         <div class='col-md-1'>


                         </div>


                      ";
}
else{
echo "no contents yet";
}
}

?>

				</div>

      </div>

    </div>

		                </div>



            </div>

	         </div>

	    </div> <!-- /.our-causes -->




	</div> <!-- /.main-container  -->
<?php include("footer.php");?>
