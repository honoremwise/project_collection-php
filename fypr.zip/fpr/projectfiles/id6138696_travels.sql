-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 02, 2018 at 09:41 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id6138696_travels`
--

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `pic` varchar(250) NOT NULL,
  `userid` int(11) NOT NULL,
  `date` date NOT NULL,
  `siteid` int(11) NOT NULL,
  `description` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `name`, `pic`, `userid`, `date`, `siteid`, `description`) VALUES
(5, 'joging', 'DSC00835.jpg', 8, '2018-06-07', 5, 'we walkk at 23'),
(20, 'contact', 'th (5) - copy.jpg', 7, '2018-06-10', 8, 'mhjvjjh'),
(21, 'traditional dancing', 'th (10).jpg', 7, '2018-06-10', 8, 'itorero indangamuco'),
(22, 'mountain climb', 'th (10) - copy.jpg', 7, '2018-06-10', 8, 'exprolation'),
(23, 'visit lions', 'th (3) - copy.jpg', 7, '2018-06-10', 8, 'forest'),
(25, 'lion', '1528790823325-933524223.jpg', 8, '2018-06-10', 9, 'wildlife'),
(26, 'hipo', 'th (11).jpg', 8, '2018-06-10', 9, 'hipology'),
(27, 'massage', 'th (3) - copy.jpg', 11, '2018-06-10', 10, 'body clean'),
(29, 'resto', '15287121049051044595669.jpg', 14, '2018-06-11', 14, 'resto chinese'),
(30, 'Inzu ya kinysrwanda', 'images (15).jpeg', 4, '2018-06-12', 15, 'Urukari');

-- --------------------------------------------------------

--
-- Table structure for table `sites`
--

CREATE TABLE `sites` (
  `site_id` int(11) NOT NULL,
  `site_name` varchar(250) NOT NULL,
  `site_logo` varchar(250) NOT NULL,
  `siteweb_link` varchar(250) NOT NULL,
  `site_email` varchar(250) NOT NULL,
  `site_service_tel` int(11) NOT NULL,
  `user_added_id` int(11) NOT NULL,
  `reg_date` date NOT NULL,
  `latitude` float(10,6) NOT NULL,
  `longitude` float(10,6) NOT NULL,
  `status` varchar(250) NOT NULL DEFAULT 'inactive'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sites`
--

INSERT INTO `sites` (`site_id`, `site_name`, `site_logo`, `siteweb_link`, `site_email`, `site_service_tel`, `user_added_id`, `reg_date`, `latitude`, `longitude`, `status`) VALUES
(8, 'remigo89', 'th (12).jpg', 'www.virrema.com', 'remi@gmai.lcom', 12547, 7, '2018-06-10', 0.000000, 0.000000, 'grant'),
(9, 'murambi', 'th (19).jpg', 'www.muhazi.com', 'mhz@gmail.com', 0, 8, '2018-06-10', -1.961275, 30.069288, 'grant'),
(10, 'akagera national park', 'ingagi.jpg', 'www.akagera.rw', 'akagera@hotmail.com', 0, 11, '2018-06-10', -1.954650, 30.060736, 'inactive'),
(12, 'muhazi', 'th (5) - copy.jpg', 'www.muhazi.com', 'muhazi@gmail.com', 784512, 13, '2018-06-11', -1.970579, 30.104429, 'inactive'),
(14, 'rubavu', '1528711526413-1632548371.jpg', 'khkmnn.GB.io', 'filo@yahoo.fr', 725678901, 14, '2018-06-11', 0.000000, 0.000000, 'inactive'),
(15, 'Arbertum', 'images.jpeg', 'Www.arb.com', 'Arb@yahoo.com', 1356, 4, '2018-06-12', 0.000000, 0.000000, 'inactive');

-- --------------------------------------------------------

--
-- Table structure for table `site_services`
--

CREATE TABLE `site_services` (
  `id` int(11) NOT NULL,
  `site_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `date` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userid` int(11) NOT NULL,
  `firstname` varchar(250) NOT NULL,
  `lastname` varchar(250) NOT NULL,
  `telephone` int(11) NOT NULL,
  `username` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `user_email` varchar(250) NOT NULL,
  `reg_date` date NOT NULL,
  `status` varchar(250) NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userid`, `firstname`, `lastname`, `telephone`, `username`, `password`, `user_email`, `reg_date`, `status`) VALUES
(4, 'noella', 'noella', 2147483647, 'admin', '7ecd103d7a073893a78cbe43aa0aae44', 'noella@gmail.com', '2018-06-09', 'active'),
(6, 'rutare', 'tito', 2147483647, 'rutare', '35056cf3019b02c1b7c4cbcfec9d39f0', 'rutare@gmail.com', '2018-06-10', 'incative'),
(7, 'dadbbbbbbba', 'cphhh', 21, 'dd', '1aabac6d068eef6a7bad3fdf50a05cc8', 'sd77@gmail.com', '2018-06-10', 'active'),
(8, 'Muragwa', 'leatithia', 676896, 'da', '5ca2aa845c8cd5ace6b016841f100d82', 'dd@gmail.com', '2018-06-10', 'active'),
(9, 'adassssssf', 'sdasfda', 6458565, 'eri', '1f5198faff59782cd71dba9588e45697', 'eri@gmail.com', '2018-06-10', 'active'),
(10, 'hi', 'hi', 14785, 'lala', '2e3817293fc275dbee74bd71ce6eb056', '', '2018-06-10', 'active'),
(11, 'mugabe', 'chazzy', 787155891, 'mugabechazzy', '9023effe3c16b0477df9b93e26d57e2c', 'munyengabechazzy@gmail.com', '2018-06-10', 'active'),
(12, 'fifi', 'fofo', 789876543, 'gajoux', '202cb962ac59075b964b07152d234b70', 'munyampunduy@gmail.com', '2018-06-10', 'active'),
(13, 'nana', 'nana', 178596, 'na', 'e10adc3949ba59abbe56e057f20f883e', 'da', '2018-06-11', 'active'),
(14, 'ira', 'felo', 725804418, 'lolo', 'c605246aaec5f39e388f039a1e76e31c', 'fizo@yahoo.fr', '2018-06-11', 'active'),
(15, 'Fizo', 'Feli', 782536984, 'Fizo', '4e47d3258c616ecb98f949bef7c01e7a', 'munyengabechazzy@gmail.', '2018-06-11', 'active'),
(16, 'Nn', 'Nono', 75236582, 'Fizo', '4e47d3258c616ecb98f949bef7c01e7a', 'Mm@yahoo.com', '2018-06-11', 'active');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userid` (`userid`);

--
-- Indexes for table `sites`
--
ALTER TABLE `sites`
  ADD PRIMARY KEY (`site_id`),
  ADD KEY `user_added_id` (`user_added_id`);

--
-- Indexes for table `site_services`
--
ALTER TABLE `site_services`
  ADD PRIMARY KEY (`id`),
  ADD KEY `site_id` (`site_id`),
  ADD KEY `service_id` (`service_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `sites`
--
ALTER TABLE `sites`
  MODIFY `site_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `sites`
--
ALTER TABLE `sites`
  ADD CONSTRAINT `sites_ibfk_1` FOREIGN KEY (`user_added_id`) REFERENCES `users` (`userid`);

--
-- Constraints for table `site_services`
--
ALTER TABLE `site_services`
  ADD CONSTRAINT `site_services_ibfk_1` FOREIGN KEY (`site_id`) REFERENCES `sites` (`site_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `site_services_ibfk_2` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
