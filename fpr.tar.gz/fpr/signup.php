<!DOCTYPE html>
<html class="no-js">
    <head>
        <meta charset="utf-8">
        <title>Final year</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Fonts -->
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,700' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Dosis:400,700' rel='stylesheet' type='text/css'>

        <!-- Bootsrap -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">


        <!-- Font awesome -->
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">

        <!-- PrettyPhoto -->
        <link rel="stylesheet" href="assets/css/prettyPhoto.css">

        <!-- Template main Css -->
        <link rel="stylesheet" href="assets/css/style.css">
        
        <!-- Modernizr -->
        <script src="assets/js/modernizr-2.6.2.min.js"></script>


    </head>
    <body>
    <!-- NAVBAR
    ================================================== -->

    <header class="main-header">
        
       <!-- NAVBAR
    ================================================== -->
                  <div class="navbar-main">
              
              <div class="container">

                <div class="navbar-header">
                  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">

                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>

                  </button>
                  
<!--                  <a class="navbar-brand" href="index.php"><img src="assets/images/sadaka-logo.png" alt=""></a>-->
                  
                </div>

                <div id="navbar" class="navbar-collapse collapse pull-right">

                  <ul class="nav navbar-nav">

                    <li><a href="index.php">HOME</a></li>
<!--                    <li><a href="about.php">ABOUT</a></li>-->
<!--
                    <li class="has-child"><a href="#">DOMAIN</a>

                      <ul class="submenu">
                         <li class="submenu-item"><a href="#">Social Sciences </a></li>
                         <li class="submenu-item"><a href="#">Pure Sciences</a></li>
                         <li class="submenu-item"><a href="#">Technical Courses </a></li>
                         <li class="submenu-item"><a href="#">Arts and Literature </a></li>
                      </ul>

                    </li> 
-->
                      

                    <li><a href="login.php">SIGN IN</a></li>
                      <li><a href="contact.php">CONTACT US</a></li>

                  </ul>

                </div> <!-- /#navbar -->

              </div> <!-- /.container -->
              
            </div> <!-- /.navbar-main -->


        </nav> 

    </header> <!-- /. main-header -->


<!--
	<div class="page-heading text-center">

		<div class="container zoomIn animated">
			
			<h1 class="page-title">Coaching Link <span class="title-under"></span></h1>
			<p class="page-description">
Online students and teachers Link  
			</p>
			
		</div>

	</div>  /. main-header 
-->
	<div class="main-container">

		<div class="our-causes fadeIn animated">

	        <div class="container">

	                <div class="row">

                        <!--php codes--->
                        <?php 
include("connection.php");
$msg="";$fname="";
if(isset($_POST["signup"]))
{
$fname=$_POST['firstname'];
$lname=$_POST['lastName'];
$email=$_POST['email'];
$pswd=$_POST['password'];
$tel=$_POST['telephone'];
    
$insert="insert into students (first_name,last_name,telephone,email,password)values ('$fname','$lname','$tel','$email','$pswd')";  
 
 $qry=mysqli_query($conn,$insert);
    if($qry)
    {
    $msg="data inserted";
          echo"<script>function redirect(){
window.location='login.php';
}setInterval(redirect,1000);</script>";
    }
    else
        $msg=mysqli_error($conn);
      echo"<script>function redirect(){
window.location='signup.php';
}setInterval(redirect,2000);</script>";
       }                 ?>
                        
                        
                        
	   <div class="col-md-3 col-sm-6">
                    </div>
           <div class="col-md-3 col-sm-6">
<br><br><br><br>
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
    <center><h4 class="modal-title" id="donateModalLabel">Students's SIGNUP FORM
        </h4></center>
              <?php 
echo "<center>".$fname.$msg."</center>";
    
?>
             
          </div>
          <div class="modal-body">

                <form class="form-donation" action="#" method="post">

                        <div class="row">
 <div class="form-group col-md-12 ">
<input type="text" class="form-control" id="amount" placeholder="First Name *" required name="firstname">  </div>

                        </div>
     <div class="row">
                            <div class="form-group col-md-12">
 <input type="text" class="form-control" name="lastName" placeholder="Last Name *" required>
                            </div>

                           
                        </div> 
                    <div class="row">
                            <div class="form-group col-md-12">
                                <input type="text" class="form-control" name="telephone" placeholder="Telephone no *" required maxlength="10" min="10">
                            </div>

                           
                        </div> 
                    <div class="row">
                            <div class="form-group col-md-12">
                                <input type="email" class="form-control" name="email" placeholder="Email *">
                            </div>

                           
                        </div> 
                    <div class="row">
                            <div class="form-group col-md-12">
                                <input type="password" class="form-control" name="password" placeholder="Password *">
                            </div>
                       
                        </div>

                    <div class="row">

                            <div class="form-group col-md-4">
                             
                            </div>
                            <div class="form-group col-md-4">
                               <CENTER><button type="submit" class="btn btn-primary pull-right" name="signup" >Submit</button></CENTER> 
                            </div>
                            <div class="form-group col-md-4">
                              
                            </div>

                        </div>



                       
                    
                </form>
            
          </div>
        </div>
      </div>

    </div>
		                    
		                </div> 

		              

            </div>

	         </div>
	        
	    </div> <!-- /.our-causes -->

		


	</div> <!-- /.main-container  -->
<?php include("footer.php");?>

   