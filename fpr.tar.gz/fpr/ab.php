   <?php
include("connection.php");
             if(isset($_POST['saves']))
{
   echo "Data not saved and uploading";  
$dates=date('Y-m-d'); 
$topic=$_POST['topic'];
$objectives=$_POST['objectives'];
$scope=$_POST['scope'];    
$supevisor=$_POST['supevisor'];
     $supid="";  
$getsup=explode('-',$supevisor);
$supid=$getsup[0];
$projectfiles_array = $_FILES['file_array']['name'];
$tmp_name_array = $_FILES['file_array']['tmp_name'];
$type_array = $_FILES['file_array']['type'];
$size_array = $_FILES['file_array']['size'];
$error_array = $_FILES['file_array']['error'];
    
 echo $dates.$topic.$objectives.$scope.$supevisor.$supid.$projectfiles_array[0];  
    
    
for($i = 0 ;$i < count($tmp_name_array); $i++){ 
    if(move_uploaded_file($tmp_name_array[$i],"projectfiles/".$projectfiles_array[$i])){
echo $projectfiles_array[$i]."is uploaded successfully ,,,,,,,,,,,,,,";

}
                                            else{
echo "Data not saved and uploading".$project_files[$i]."failed<br>";
                                            }
                                           }    
$binserts="insert  into `projects`
(topic,project_report,video_tutorial,project_file,objectives,sid,scope_summary)values
('$topic','$project_files[0]','$project_files[1]',
'$project_files[2]','$objectives','$supid','$scope')";
$bresult = mysqli_query($binserts);     
                 if($bresult)
    {
      echo "<i class='fa fa-info' style='color:red;'>Project uploaded successfully123</i>";
        echo"<script>function redirect(){
window.location='students.php';
}setInterval(redirect,1000);</script>";
   }
    else
         echo "hihihhhhhhhhhhhhhhhhhhhhhhh".mysqli_error();                                  

             }
             ?>