<?php
$server="127.0.0.1";
$user="root";
$pswd="12345";
$db="projectsdb";
$conn=mysqli_connect($server,$user,$pswd,$db);
?>