<?php
include("connection.php");
include'auth.php';
$username=$_SESSION['email'];
$id="";$m="";$usertype="";
//getting trainers data
$dc="select * from teachers where status='active' and (email_address ='$username' or telephone='$username')";
$qry=mysqli_query($conn,$dc);
$countteach=mysqli_num_rows($qry);
$row=mysqli_fetch_array($qry);
$id=$row['id'];
$tr="select * from students where (email ='$username' or telephone='$username') and status='active'";
$st=mysqli_query($conn,$tr);
$countst=mysqli_num_rows($st);
$read=mysqli_fetch_array($st);
$id=$read['id'];
if($countteach===1)
{

//echo $username;
$usertype="teacher";
echo"<script>function redirect(){
window.location='trainerspage.php';
}setInterval(redirect,200);</script>";
}
//getting student data

if($countst===1)
{
$usertype="student";
echo"<script>function redirect(){
window.location='students.php';
}setInterval(redirect,1000);</script>";
} 

if(isset($_POST['adddoc']))
{
   //echo "Data not saved and uploading";  
$experience=$_POST['experience'];
$descr=$_POST['descr'];
$projectfiles_array = $_FILES['file_array']['name'];
$tmp_name_array = $_FILES['file_array']['tmp_name'];
$type_array = $_FILES['file_array']['type'];
$size_array = $_FILES['file_array']['size'];
$error_array = $_FILES['file_array']['error'];
    for($i = 0 ;$i < count($tmp_name_array); $i++){ 
    if(move_uploaded_file($tmp_name_array[$i],"documents/".$projectfiles_array[$i])){
echo $projectfiles_array[$i]."is uploaded successfully ,,,,,,,,,,,,,,";

}
                                            else{
echo "Data not saved and uploading".$projectfiles_array[$i]."failed<br>";
                                            }
                                           }     
$binserts="insert  into users_requirements
(userid,prove_document,experience,usertype,description,status)values
(2,'$projectfiles_array[0]','$experience','$usertype','$descr','complete')";
$bresult = mysqli_query($conn,$binserts);     
                 if($bresult)
    {
      echo "<i class='fa fa-info' style='color:red;'>Document uploaded successfully123</i>";
                     if($usertype='student')
                     {
        echo"<script>function redirect(){
window.location='students.php';
}setInterval(redirect,200);</script>";
                         }
                     else
 echo"<script>function redirect(){
window.location='trainerspage.php';
}setInterval(redirect,200);</script>";
                         
   }
    else
         echo "".mysqli_error($conn);                                  

             }  
                        ?>
                        