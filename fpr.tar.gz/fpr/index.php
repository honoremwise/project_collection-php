<?php include("connection.php");
include("menu.php");?>

        <div class="container">
<h2 class="title-style-1">Posted Projects<span class="title-under"></span></h2>
            <div class="row">
                
                            <div role="tabpanel" class="tab-pane active" id="home">
              <?php
include("connection.php");
$m_id="";$teacher_id="";$module_name="";$module_details="";$category="";
$sql="SELECT * FROM projectstbl";
$modules=mysqli_query($conn,$sql);
$num=mysqli_num_rows($modules);

if($num>0)
{
while($recs=mysqli_fetch_array($modules))
{
//$m_id=$recs['m_id'];
$name=$recs['name'];
$module_name=$recs['name'];
 $module_details=$recs['detail'];
  $category=$recs['category'];
    if($category=="ICT"){
    echo' <div class="col-md-3">

                    <div class="reasons-col animate-onscroll fadeIn">

         <h1><i class="fa fa-file-code-o" style="font-size:700%"></i></h1>
                        <div class="reasons-titles">

                            <h3 class="reasons-title">'.$module_name.'</h3>
                            <h5 class="reason-subtitle">Category:'.$category.'</h5>
                            
                        </div>

                        <div class="on-hover hidden-xs">';
    echo"<center><h4><u>Project Short Description</u><h4></center>";                        
 echo'

                                <p> '.$module_details.'
                                                                </p>

                             ';
                     echo"<h5> 
                  <a href='#' data-toggle='modal' data-target='#donateModal'><i class='fa fa-eye'> More </i></a>
                  <h5>        
                        </div>
                    </div>
                    
                </div>";
    
    }
    else if($category=="ELECTRONICS")
    {
    echo' <div class="col-md-3">

                    <div class="reasons-col animate-onscroll fadeIn">

         <h1><i class="fa fa-wrench" style="font-size:700%"></i></h1>
                        <div class="reasons-titles">

                            <h3 class="reasons-title">'.$module_name.'</h3>
                            <h5 class="reason-subtitle">Category:'.$category.'</h5>
                            
                        </div>

                        <div class="on-hover hidden-xs">';
    echo"<center><h4><u>projectShort Description</u><h4></center>";                        
 echo'

                                <p> '.$module_details.'
                                                                </p>

                              ';
                   echo"<h5> 
                  <a href='#' data-toggle='modal' data-target='#donateModal'><i class='fa fa-eye'> More </i></a>
                  <h5>        
                        </div>
                    </div>
                    
                </div>";
    
    }
    else if($category=="CIVIL ENGENEERING")
   {
    echo' <div class="col-md-3">

                    <div class="reasons-col animate-onscroll fadeIn">

         <h1><i class="fa fa-home" style="font-size:700%"></i></h1>
                        <div class="reasons-titles">

                            <h3 class="reasons-title">'.$module_name.'</h3>
                            <h5 class="reason-subtitle">Category:'.$category.'</h5>
                            
                        </div>

                        <div class="on-hover hidden-xs">';
    echo"<center><h4><u>Project Short Description</u><h4></center>";                        
 echo'
                                <p> '.$module_details.'
                                                                </p>
';
                   echo"<h5> 
                  <a href='#' data-toggle='modal' data-target='#donateModal'><i class='fa fa-eye'> More </i></a>
                  <h5>       
                        </div>
                    </div>
                    
                </div>";
    
    }
else
{
    echo' <div class="col-md-3">

                    <div class="reasons-col animate-onscroll fadeIn">

         <h1><i class="fa fa-wifi" style="font-size:700%"></i></h1>
                        <div class="reasons-titles">

                            <h3 class="reasons-title">'.$module_name.'</h3>
                            <h5 class="reason-subtitle">Category:'.$category.'</h5>
                            
                        </div>

                        <div class="on-hover hidden-xs">';
    echo"<center><h4><u>Mproject Short Description</u><h4></center>";                        
 echo'
                                <p> '.$module_details.'
                                                                </p>

                                ';
                  echo"<h5> 
                  <a href='#' data-toggle='modal' data-target='#donateModal'><i class='fa fa-eye'> More </i></a>
                  <h5>      
                        </div>
                    </div>
                    
                </div>";
    echo"<br>";
    
    }

}

}
                      
                                    ?>
                                                
							</div>              
        </div>
      
    </div> <!-- /.home-reasons -->
<br><br>
   <div class="modal fade" id="donateModal" tabindex="-1" role="dialog" aria-labelledby="donateModalLabel" aria-hidden="true">

      <div class="modal-dialog">
        <div class="modal-content">
<!--
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="donateModalLabel">COURSES Details</h4>
          </div>
-->
          <div class="modal-body">
             Dear user please first of all <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <br> <br>
              <div class="row">
            <div class="form-group col-md-4">
              <center> <a href="signup.php"> <button type="submit" class="btn btn-primary pull-center" name="donateNow" >Students sign up </button></a> </center> 
                            </div> 
<!--
                  <div class="form-group col-md-4">
              <center> <a href="signup1.php"> <button type="submit" class="btn btn-primary pull-center" name="donateNow" >supervisor sign up </button></a> </center>
                            </div>
-->
                  <div class="form-group col-md-4">
                <a href="login.php"> <button type="submit" class="btn btn-primary pull-center" name="donateNow" >sign in</button></a> 
                            </div>
              </div>
          </div>
        </div>
      </div>

    </div>
    <!--  Scripts
    ================================================== -->

    <!-- jQuery -->
   <?php include("footer.php");?>
